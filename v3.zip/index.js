//We are all about the laughts.
//Everybody wants short and quick funny sayings to cheer them up.

/*
There are a few moments on our everyday life, that we all need a quick joke. funny sayings is all about the laughs.
We are here to make your day just a bit better.
*/

//Alexa, ask funny sayings to tell me a joke
//Alexa, ask funny sayings to tell me another one

'use strict';
var Alexa = require('alexa-sdk');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Calculator';

var unirest = require('unirest');

var theEvent;
var theContext;

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    theEvent = event;
    theContext = context;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
         this.emit(':ask', "Are you ready to have some fun? If you want a joke, just ask for it", SKILL_NAME)
    },
    'Add': function () {
        
        if(theEvent === null){
	        this.emit(':tell', "event null", SKILL_NAME);
        }else{
	        
	        var num1  = parseFloat(theEvent.request.intent.slots.NumOne.value);
	        var num2  = parseFloat(theEvent.request.intent.slots.NumTwo.value);
	       	
	       	var result = num1 + num2;
	       	
	       	var reply = num1+" plus "+num2+" equals "+result;
			this.emit(':tellWithCard',reply, SKILL_NAME);
	      
        }
        
    },
    'Subtract': function () {
        
        if(theEvent === null){
	        this.emit(':tell', "event null", SKILL_NAME);
        }else{
	        
	        var num1  = parseFloat(theEvent.request.intent.slots.NumOne.value);
	        var num2  = parseFloat(theEvent.request.intent.slots.NumTwo.value);
	       	
	       	var result = num2 - num1;
	       	
	       	var reply = num2+" minus "+num1+" equals "+result;
			this.emit(':tellWithCard',reply, SKILL_NAME);
	      
        }
        
    },
    'Multiply': function () {
        
        if(theEvent === null){
	        this.emit(':tell', "event null", SKILL_NAME);
        }else{
	        
	        var num1  = parseFloat(theEvent.request.intent.slots.NumOne.value);
	        var num2  = parseFloat(theEvent.request.intent.slots.NumTwo.value);
	       	
	       	var result = num2 * num1;
	       	
	       	var reply = num1+" times "+num2+" equals "+result;
			this.emit(':tellWithCard',reply, SKILL_NAME);
	      
        }
        
    },
    'Divide': function () {
        
        if(theEvent === null){
	        this.emit(':tell', "event null", SKILL_NAME);
        }else{
	        
	        var num1  = parseFloat(theEvent.request.intent.slots.NumOne.value);
	        var num2  = parseFloat(theEvent.request.intent.slots.NumTwo.value);
	       	
	       	var result = num1/num1;
	       	
	       	var reply = num1+" divided by "+num2+" equals "+result;
			this.emit(':tellWithCard',reply, SKILL_NAME);
	      
        }
        
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "I am here just to tell you jokes...";
        var reprompt = "What can I help you with?";
        this.emit(':tell', speechOutput, reprompt);
    },
    
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Goodbye!');
    },
    
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye!');
    }
};